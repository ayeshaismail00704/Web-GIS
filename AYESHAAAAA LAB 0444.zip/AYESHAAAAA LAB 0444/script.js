// Initialize map centered on Pakistan
var map = L.map('map').setView([30.3753, 69.3451], 5);

// Basemaps
var osm = L.tileLayer(
    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    { attribution: '© OpenStreetMap contributors' }
);

var satellite = L.tileLayer(
    'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    { attribution: 'Tiles © Esri' }
);

osm.addTo(map);

var baseMaps = {
    "OpenStreetMap": osm,
    "Satellite Imagery": satellite
};

var layerControl = L.control.layers(baseMaps, {}).addTo(map);

// Layer order (higher number = on top)
map.createPane('rainfallPane');
map.getPane('rainfallPane').style.zIndex = 410;

map.createPane('aqiPane');
map.getPane('aqiPane').style.zIndex = 420;

map.createPane('weatherPane');
map.getPane('weatherPane').style.zIndex = 430;

map.createPane('citiesPane');
map.getPane('citiesPane').style.zIndex = 440;


// ---------------- RAINFALL STATIONS ----------------
fetch('data/rainfall_stations.geojson')
    .then(response => {
        if (!response.ok) throw new Error("rainfall_stations.geojson not found (" + response.status + ")");
        return response.json();
    })
    .then(data => {

        var rainfallLayer = L.geoJSON(data, {

            pointToLayer: function (feature, latlng) {
                return L.circleMarker(latlng, {
                    pane: 'rainfallPane',
                    radius: 22,
                    color: "green",
                    weight: 3,
                    fillColor: "green",
                    fillOpacity: 0.1
                });
            },

            onEachFeature: function (feature, layer) {
                layer.bindPopup(
                    "<b>Station:</b> " + feature.properties.station +
                    "<br><b>Rainfall:</b> " + feature.properties.rainfall + " mm"
                );
            }

        }).addTo(map);

        layerControl.addOverlay(rainfallLayer, "Rainfall Stations");
    })
    .catch(error => {
        console.error("Error loading rainfall GeoJSON:", error);
        alert("Could not load data/rainfall_stations.geojson. Check the file path and that you're using a local server.");
    });


// ---------------- AIR QUALITY (attribute based symbol) ----------------

// AQI < 50 = small, 50-100 = medium, > 100 = large
function getAQIRadius(aqi) {
    if (aqi < 50) {
        return 5;      // Small
    } else if (aqi <= 100) {
        return 10;     // Medium
    } else {
        return 16;     // Large
    }
}

fetch('data/air_quality.geojson')
    .then(response => {
        if (!response.ok) throw new Error("air_quality.geojson not found (" + response.status + ")");
        return response.json();
    })
    .then(data => {

        var aqiLayer = L.geoJSON(data, {

            pointToLayer: function (feature, latlng) {
                return L.circleMarker(latlng, {
                    pane: 'aqiPane',
                    radius: getAQIRadius(feature.properties.aqi),
                    fillColor: "purple",
                    color: "black",
                    weight: 1,
                    opacity: 1,
                    fillOpacity: 0.6
                });
            },

            onEachFeature: function (feature, layer) {
                layer.bindPopup(
                    "<b>City:</b> " + feature.properties.city +
                    "<br><b>AQI:</b> " + feature.properties.aqi +
                    "<br><b>Level:</b> " + feature.properties.level
                );
            }

        }).addTo(map);

        layerControl.addOverlay(aqiLayer, "Air Quality (AQI)");
    })
    .catch(error => {
        console.error("Error loading air quality GeoJSON:", error);
        alert("Could not load data/air_quality.geojson. Check the file path and that you're using a local server.");
    });


// ---------------- WEATHER STATIONS ----------------
fetch('data/weather_stations.geojson')
    .then(response => {
        if (!response.ok) throw new Error("weather_stations.geojson not found (" + response.status + ")");
        return response.json();
    })
    .then(data => {

        var weatherLayer = L.geoJSON(data, {

            pointToLayer: function (feature, latlng) {
                return L.circleMarker(latlng, {
                    pane: 'weatherPane',
                    radius: 6,
                    color: "blue",
                    fillColor: "blue",
                    fillOpacity: 0.7
                });
            },

            onEachFeature: function (feature, layer) {
                layer.bindPopup(
                    "<b>Station:</b> " + feature.properties.station +
                    "<br><b>Temperature:</b> " + feature.properties.temperature + "°C" +
                    "<br><b>Rainfall:</b> " + feature.properties.rainfall + " mm"
                );
            }

        }).addTo(map);

        layerControl.addOverlay(weatherLayer, "Weather Stations");
    })
    .catch(error => {
        console.error("Error loading weather stations GeoJSON:", error);
        alert("Could not load data/weather_stations.geojson. Check the file path and that you're using a local server.");
    });


// ---------------- CITIES ----------------
fetch('data/cities.geojson')
    .then(response => {
        if (!response.ok) throw new Error("cities.geojson not found (" + response.status + ")");
        return response.json();
    })
    .then(data => {

        var citiesLayer = L.geoJSON(data, {

            pointToLayer: function (feature, latlng) {
                return L.circleMarker(latlng, {
                    pane: 'citiesPane',
                    radius: 3,
                    fillColor: "red",
                    color: "black",
                    weight: 1,
                    opacity: 1,
                    fillOpacity: 1
                });
            },

            onEachFeature: function (feature, layer) {
                layer.bindPopup(
                    "<b>City:</b> " + feature.properties.name +
                    "<br><b>Province:</b> " + feature.properties.province +
                    "<br><b>Type:</b> " + feature.properties.type
                );
            }

        }).addTo(map);

        layerControl.addOverlay(citiesLayer, "Major Cities");
    })
    .catch(error => {
        console.error("Error loading cities GeoJSON:", error);
        alert("Could not load data/cities.geojson. Check the file path and that you're using a local server.");
    });